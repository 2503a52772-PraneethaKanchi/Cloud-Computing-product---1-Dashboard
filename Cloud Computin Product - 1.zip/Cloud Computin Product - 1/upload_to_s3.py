"""
AWS S3 Dashboard Upload Utility for 'virtual-classroom-acess-gate-s3'
Uploads index.html, style.css, and script.js with correct MIME content-types
to your Amazon S3 Static Website Hosting bucket.
"""

import os
import sys
import boto3
from botocore.exceptions import ClientError, NoCredentialsError

BUCKET_NAME = "virtual-classroom-acess-gate-s3"
REGION = "us-east-1"
WEBSITE_URL = f"http://{BUCKET_NAME}.s3-website-{REGION}.amazonaws.com"

FILES_TO_UPLOAD = [
    ("index.html", "text/html"),
    ("style.css", "text/css"),
    ("script.js", "application/javascript")
]

def upload_dashboard():
    print("=" * 68)
    print(" 🚀 UPLOADING DASHBOARD TO AMAZON S3 STATIC WEBSITE")
    print(f" Target Bucket : {BUCKET_NAME}")
    print(f" AWS Region    : {REGION}")
    print(f" Website URL   : {WEBSITE_URL}")
    print("=" * 68)

    # Initialize S3 Client
    try:
        s3 = boto3.client('s3', region_name=REGION)
        # Quick validation call
        s3.head_bucket(Bucket=BUCKET_NAME)
    except NoCredentialsError:
        print("\n❌ No AWS credentials found!")
        print("Please provide your AWS credentials to proceed.")
        ak = input("Enter AWS Access Key ID: ").strip()
        sk = input("Enter AWS Secret Access Key: ").strip()
        if not ak or not sk:
            print("Credentials cannot be empty. Exiting.")
            return
        s3 = boto3.client(
            's3',
            region_name=REGION,
            aws_access_key_id=ak,
            aws_secret_access_key=sk
        )
    except ClientError as e:
        error_code = e.response.get('Error', {}).get('Code')
        if error_code == '403':
            print(f"\n⚠️ Access denied to bucket '{BUCKET_NAME}'. Check your IAM permissions.")
            return
        elif error_code == '404':
            print(f"\n⚠️ Bucket '{BUCKET_NAME}' does not exist in region '{REGION}'.")
            return
        else:
            print(f"\n⚠️ Warning: {e}")

    # Upload files with appropriate Content-Type
    base_dir = os.path.dirname(os.path.abspath(__file__))

    for filename, content_type in FILES_TO_UPLOAD:
        file_path = os.path.join(base_dir, filename)
        if not os.path.exists(file_path):
            print(f"❌ File not found: {filename}")
            continue

        print(f"Uploading {filename} (Content-Type: {content_type})...")
        try:
            s3.upload_file(
                Filename=file_path,
                Bucket=BUCKET_NAME,
                Key=filename,
                ExtraArgs={
                    'ContentType': content_type
                }
            )
            print(f"  ✔ {filename} uploaded successfully!")
        except Exception as e:
            print(f"  ❌ Failed to upload {filename}: {e}")

    print("\n" + "=" * 68)
    print("🎉 DEPLOYMENT COMPLETE!")
    print(f"👉 Open your live AWS Dashboard here:")
    print(f"   {WEBSITE_URL}")
    print("=" * 68)

if __name__ == '__main__':
    upload_dashboard()
