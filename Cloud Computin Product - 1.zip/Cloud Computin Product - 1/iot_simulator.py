"""
Virtual Classroom Access Gate - IoT Terminal Simulator
Simulates RFID Card Taps on ESP32 without physical hardware attached.
Sends MQTT / HTTP requests to the backend / AWS Lambda and shows instant LED and Subnet results.
"""

import time
import requests
import json
import sys

BASE_URL = "http://localhost:5000"

STUDENT_CARDS = [
    {"name": "D. Taejaswini", "roll": "2503A52752", "uid": "A3:4F:91:2B", "type": "Registered Student"},
    {"name": "B. Mounika", "roll": "2503A52756", "uid": "B8:21:7C:90", "type": "Registered Student"},
    {"name": "V. Pragathi Vijaya Lakshmi", "roll": "2503A52761", "uid": "C1:89:33:DE", "type": "Registered Student"},
    {"name": "A. Spurthi", "roll": "2503A52764", "uid": "D4:55:1A:F2", "type": "Registered Student"},
    {"name": "Praneetha Kanchi", "roll": "2503A52772", "uid": "E9:60:44:0B", "type": "Registered Student"},
    {"name": "Guest Student", "roll": "2503A59999", "uid": "F0:11:82:77", "type": "Expired Access"},
    {"name": "Unknown Intruder", "roll": "UNKNOWN", "uid": "99:AA:BB:CC", "type": "Unregistered Tag"},
]

def simulate_card_tap(card):
    print("\n" + "=" * 55)
    print(f"📡 [RFID SCAN DETECTED] Tag UID: {card['uid']}")
    print(f"   Student Profile: {card['name']} ({card['roll']})")
    print("   Sending payload to Virtual Classroom Gate...")
    print("=" * 55)

    payload = {
        "tag_uid": card["uid"],
        "name": card["name"],
        "rollNo": card["roll"],
        "subnet": "192.168.10.0/24"
    }

    try:
        res = requests.post(f"{BASE_URL}/api/scan", json=payload, timeout=3)
        if res.status_code == 200:
            data = res.json()
            decision = data.get("decision")
            assigned_ip = data.get("assignedIp")
            reason = data.get("reason")

            if decision == "ALLOWED":
                print(f"🟢 [GATE DECISION] >> ALLOWED <<")
                print(f"   [HARDWARE LED]  >> GREEN LED ON (2.5 seconds) <<")
                print(f"   [SUBNET IP]     >> Allocated IP: {assigned_ip} <<")
                print(f"   [REASON]        >> {reason} <<")
            else:
                print(f"🔴 [GATE DECISION] >> DENIED <<")
                print(f"   [HARDWARE LED]  >> RED LED ON (2.0 seconds) <<")
                print(f"   [SUBNET IP]     >> None (Access Blocked) <<")
                print(f"   [REASON]        >> {reason} <<")
        else:
            print(f"Error from server: HTTP {res.status_code}")
    except requests.exceptions.ConnectionError:
        print("⚠️ Server at http://localhost:5000 is not running.")
        print("   Start the backend server using: python app.py")
        # Offline display
        if card["uid"] in ["A3:4F:91:2B", "B8:21:7C:90", "C1:89:33:DE", "D4:55:1A:F2", "E9:60:44:0B"]:
            print(f"🟢 [OFFLINE LOGIC] >> ALLOWED -> GREEN LED ON")
        else:
            print(f"🔴 [OFFLINE LOGIC] >> DENIED  -> RED LED ON")

def main():
    print("*" * 60)
    print(" VIRTUAL CLASSROOM ACCESS GATE - IOT TERMINAL SIMULATOR")
    print("*" * 60)
    print("Select a card to tap on the gate:")
    for idx, c in enumerate(STUDENT_CARDS, 1):
        print(f"  [{idx}] {c['name']} ({c['roll']}) - UID: {c['uid']} [{c['type']}]")
    print("  [8] Run continuous automated traffic demo")
    print("  [0] Exit")

    choice = input("\nEnter selection (0-8): ").strip()
    if choice in [str(i) for i in range(1, len(STUDENT_CARDS) + 1)]:
        simulate_card_tap(STUDENT_CARDS[int(choice) - 1])
    elif choice == "8":
        print("\nStarting automated traffic stream (Ctrl+C to stop)...")
        import random
        try:
            while True:
                c = random.choice(STUDENT_CARDS)
                simulate_card_tap(c)
                time.sleep(3)
        except KeyboardInterrupt:
            print("\nDemo stopped.")
    else:
        print("Exiting.")

if __name__ == "__main__":
    main()
