"""
AWS Lambda Function: Virtual Classroom Access Gate Processor
Handler triggered by AWS IoT Core Rule on topic: 'classroom/gate/request'

Flow:
1. Parse JSON payload from ESP32 (device_id, tag_uid, timestamp).
2. Query DynamoDB Table: 'StudentRoster' for the RFID tag UID.
3. Determine Access Decision:
   - If registered & active -> ALLOWED (LED: GREEN, Subnet IP assigned)
   - If not found or expired -> DENIED (LED: RED)
4. Persist Audit Record into DynamoDB Table: 'GateAccessLogs'.
5. Publish Decision to AWS IoT Core topic: 'classroom/gate/response'
   which commands the ESP32 to activate Green or Red LED.
"""

import json
import os
import time
import boto3
from datetime import datetime

# AWS Clients
dynamodb = boto3.resource('dynamodb')
iot_data = boto3.client('iot-data')

# Environment or default table names
STUDENT_TABLE_NAME = os.environ.get('STUDENT_TABLE', 'VirtualClassroom_StudentRoster')
LOGS_TABLE_NAME = os.environ.get('LOGS_TABLE', 'VirtualClassroom_AccessLogs')
RESPONSE_TOPIC = os.environ.get('RESPONSE_TOPIC', 'classroom/gate/response')

# Fallback whitelist in memory if running standalone demo
REGISTERED_STUDENTS_FALLBACK = {
    "A3:4F:91:2B": {"name": "D. Taejaswini", "roll_no": "2503A52752", "ip": "192.168.10.15", "status": "ACTIVE"},
    "B8:21:7C:90": {"name": "B. Mounika", "roll_no": "2503A52756", "ip": "192.168.10.16", "status": "ACTIVE"},
    "C1:89:33:DE": {"name": "V. Pragathi Vijaya Lakshmi", "roll_no": "2503A52761", "ip": "192.168.10.17", "status": "ACTIVE"},
    "D4:55:1A:F2": {"name": "A. Spurthi", "roll_no": "2503A52764", "ip": "192.168.10.18", "status": "ACTIVE"},
    "E9:60:44:0B": {"name": "Praneetha Kanchi", "roll_no": "2503A52772", "ip": "192.168.10.19", "status": "ACTIVE"},
}


def lambda_handler(event, context):
    print(f"Received AWS IoT Event: {json.dumps(event)}")

    # 1. Extract payload fields sent by ESP32
    device_id = event.get('device_id', 'ESP32_GATE_01')
    tag_uid = event.get('tag_uid', '').strip().upper()
    req_timestamp = event.get('timestamp', datetime.utcnow().isoformat())
    target_subnet = event.get('subnet', '192.168.10.0/24')

    if not tag_uid:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Missing tag_uid in payload'})
        }

    # 2. Query DynamoDB Student Table
    student_record = None
    try:
        student_table = dynamodb.Table(STUDENT_TABLE_NAME)
        response = student_table.get_item(Key={'tag_uid': tag_uid})
        student_record = response.get('Item')
    except Exception as e:
        print(f"DynamoDB query failed ({e}); checking fallback directory.")
        if tag_uid in REGISTERED_STUDENTS_FALLBACK:
            student_record = REGISTERED_STUDENTS_FALLBACK[tag_uid]

    # 3. Decision Logic: Check if Student is Authorized
    if student_record and student_record.get('status') == 'ACTIVE':
        decision = "ALLOWED"
        led_color = "GREEN"
        student_name = student_record.get('name', 'Student')
        roll_no = student_record.get('roll_no', 'N/A')
        assigned_ip = student_record.get('ip', '192.168.10.20')
        reason = "Subnet Authorization Verified (Cloud Sec-A)"
    else:
        decision = "DENIED"
        led_color = "RED"
        student_name = student_record.get('name', 'Unknown') if student_record else 'Unknown Card'
        roll_no = student_record.get('roll_no', 'UNKNOWN') if student_record else 'UNKNOWN'
        assigned_ip = "None"
        reason = "Unauthorized UID or Expired Subnet Permission"

    # 4. Construct Access Log Item
    log_id = f"LOG-{int(time.time() * 1000)}"
    log_entry = {
        'log_id': log_id,
        'timestamp': datetime.now().strftime("%H:%M:%S"),
        'device_id': device_id,
        'tag_uid': tag_uid,
        'student_name': student_name,
        'roll_no': roll_no,
        'assigned_ip': assigned_ip,
        'subnet': target_subnet,
        'decision': decision,
        'led_activated': led_color,
        'reason': reason
    }

    # Persist log to DynamoDB
    try:
        logs_table = dynamodb.Table(LOGS_TABLE_NAME)
        logs_table.put_item(Item=log_entry)
        print(f"Logged entry {log_id} to DynamoDB successfully.")
    except Exception as e:
        print(f"Warning: Could not save log entry to DynamoDB: {e}")

    # 5. Prepare MQTT Response for ESP32 Gate Controller
    response_payload = {
        'device_id': device_id,
        'tag_uid': tag_uid,
        'decision': decision,
        'led': led_color,       # GREEN or RED
        'student_name': student_name,
        'roll_no': roll_no,
        'assigned_ip': assigned_ip,
        'gate_open': (decision == "ALLOWED"),
        'server_timestamp': datetime.utcnow().isoformat()
    }

    # Publish message back to ESP32 topic
    try:
        iot_data.publish(
            topic=RESPONSE_TOPIC,
            qos=1,
            payload=json.dumps(response_payload)
        )
        print(f"Published response to MQTT topic '{RESPONSE_TOPIC}': {response_payload}")
    except Exception as e:
        print(f"Failed to publish to AWS IoT Core: {e}")

    return {
        'statusCode': 200,
        'body': json.dumps(response_payload)
    }
