/* ==============================================================================
 * Project: Virtual Classroom Access Gate
 * Hardware: ESP32 + MFRC522 RFID Reader + Status LEDs (Green / Red)
 * Cloud: AWS IoT Core, AWS Lambda, Amazon DynamoDB
 *
 * Circuit Pin Connections:
 * -------------------------------------------------------------
 *  MFRC522 RFID Pin  | ESP32 Pin  | Description
 * -------------------------------------------------------------
 *  SDA (SS)          | GPIO 5     | SPI Chip Select
 *  SCK               | GPIO 18    | SPI Clock
 *  MOSI              | GPIO 23    | SPI MOSI
 *  MISO              | GPIO 19    | SPI MISO
 *  RST               | GPIO 22    | Reset Pin
 *  3.3V              | 3.3V       | Power (Do NOT use 5V for RC522)
 *  GND               | GND        | Ground
 * -------------------------------------------------------------
 *  LED Indicators    | ESP32 Pin  | Description
 * -------------------------------------------------------------
 *  Green LED Anode   | GPIO 2     | Access ALLOWED (220 Ohm resistor)
 *  Red LED Anode     | GPIO 4     | Access DENIED (220 Ohm resistor)
 *  LED Cathodes      | GND        | Common Ground
 * ============================================================================== */

#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <SPI.h>
#include <MFRC522.h>

// --- WiFi Credentials ---
const char* WIFI_SSID     = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

// --- AWS IoT Core Configuration ---
const char* AWS_IOT_ENDPOINT = "a2xxxxxxxxxxxx-ats.iot.us-east-1.amazonaws.com"; // Replace with your endpoint
const int   AWS_IOT_PORT     = 8883;
const char* DEVICE_ID        = "ESP32_GATE_01";
const char* TOPIC_PUBLISH    = "classroom/gate/request";
const char* TOPIC_SUBSCRIBE  = "classroom/gate/response";

// --- Hardware Pins ---
#define PIN_SS       5
#define PIN_RST      22
#define PIN_LED_GRN  2   // Green LED for ALLOWED
#define PIN_LED_RED  4   // Red LED for DENIED

// --- AWS IoT X.509 Certificates (Paste from AWS IoT Console) ---
static const char AWS_CERT_CA[] PROGMEM = R"EOF(
-----BEGIN CERTIFICATE-----
MIIDQTCCAimgAwIBAgITBmyfz5m/jAo54vB4ikPmljZbyjANBgkqhkiG9w0BAQsF
... (Paste Amazon Root CA 1 Certificate here) ...
-----END CERTIFICATE-----
)EOF";

static const char AWS_CERT_CRT[] PROGMEM = R"EOF(
-----BEGIN CERTIFICATE-----
MIIDWjCCAkKgAwIBAgIVAM...
... (Paste Device Certificate .pem.crt here) ...
-----END CERTIFICATE-----
)EOF";

static const char AWS_CERT_PRIVATE[] PROGMEM = R"EOF(
-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEAz...
... (Paste Device Private Key .pem.key here) ...
-----END RSA PRIVATE KEY-----
)EOF";

// Instances
MFRC522 rfid(PIN_SS, PIN_RST);
WiFiClientSecure netClient;
PubSubClient mqttClient(netClient);

// Anti-spam debounce for card reading
unsigned long lastScanTime = 0;
const unsigned long SCAN_DEBOUNCE_MS = 2500;

// Connect to WiFi
void connectWiFi() {
  Serial.print("Connecting to WiFi: ");
  Serial.println(WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi Connected! IP Address: ");
  Serial.println(WiFi.localIP());
}

// MQTT Message Received Callback (Processes decision from AWS Lambda)
void mqttCallback(char* topic, byte* payload, unsigned int length) {
  Serial.print("\n[AWS IoT] Incoming message on topic: ");
  Serial.println(topic);

  // Parse JSON response
  StaticJsonDocument<512> doc;
  DeserializationError error = deserializeJson(doc, payload, length);

  if (error) {
    Serial.print("JSON Deserialization failed: ");
    Serial.println(error.c_str());
    return;
  }

  const char* decision   = doc["decision"];     // "ALLOWED" or "DENIED"
  const char* led        = doc["led"];          // "GREEN" or "RED"
  const char* student    = doc["student_name"]; // e.g. "Praneetha Kanchi"
  const char* assignedIp = doc["assigned_ip"];  // e.g. "192.168.10.19"

  Serial.println("========================================");
  Serial.printf(" GATE DECISION : %s\n", decision);
  Serial.printf(" STUDENT NAME  : %s\n", student);
  Serial.printf(" ASSIGNED IP   : %s\n", assignedIp);
  Serial.println("========================================");

  if (strcmp(decision, "ALLOWED") == 0) {
    // Access Granted: Turn ON Green LED for 2.5 seconds
    Serial.println(">> Green LED ON: Turnstile Gate Unlocked");
    digitalWrite(PIN_LED_GRN, HIGH);
    digitalWrite(PIN_LED_RED, LOW);
    delay(2500);
    digitalWrite(PIN_LED_GRN, LOW);
  } else {
    // Access Denied: Blink Red LED
    Serial.println(">> Red LED ON: Access Denied, Gate Locked");
    digitalWrite(PIN_LED_RED, HIGH);
    digitalWrite(PIN_LED_GRN, LOW);
    delay(2000);
    digitalWrite(PIN_LED_RED, LOW);
  }
}

// Connect to AWS IoT Core MQTT Broker
void connectAWS() {
  netClient.setCACert(AWS_CERT_CA);
  netClient.setCertificate(AWS_CERT_CRT);
  netClient.setPrivateKey(AWS_CERT_PRIVATE);

  mqttClient.setServer(AWS_IOT_ENDPOINT, AWS_IOT_PORT);
  mqttClient.setCallback(mqttCallback);

  while (!mqttClient.connected()) {
    Serial.print("Connecting to AWS IoT Core...");
    if (mqttClient.connect(DEVICE_ID)) {
      Serial.println(" Connected successfully!");
      mqttClient.subscribe(TOPIC_SUBSCRIBE);
      Serial.print("Subscribed to: ");
      Serial.println(TOPIC_SUBSCRIBE);
    } else {
      Serial.print(" Failed, rc=");
      Serial.print(mqttClient.state());
      Serial.println(" Retrying in 4 seconds...");
      delay(4000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  // Initialize LED Pins
  pinMode(PIN_LED_GRN, OUTPUT);
  pinMode(PIN_LED_RED, OUTPUT);
  digitalWrite(PIN_LED_GRN, LOW);
  digitalWrite(PIN_LED_RED, LOW);

  // Initialize SPI & MFRC522 RFID Reader
  SPI.begin();
  rfid.PCD_Init();
  Serial.println("RFID Reader MFRC522 Initialized.");

  // Connect Network & AWS IoT
  connectWiFi();
  connectAWS();

  Serial.println(">> Virtual Classroom Access Gate Hardware Ready! Tap Card...");
}

void loop() {
  // Maintain MQTT Connection
  if (!mqttClient.connected()) {
    connectAWS();
  }
  mqttClient.loop();

  // Check if a new RFID card is present on the reader
  if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) {
    return;
  }

  // Prevent multiple reads of the same card in quick succession
  if (millis() - lastScanTime < SCAN_DEBOUNCE_MS) {
    rfid.PICC_HaltA();
    rfid.PCD_StopCrypto1();
    return;
  }
  lastScanTime = millis();

  // Format Tag UID into hex string: XX:XX:XX:XX
  String tagUid = "";
  for (byte i = 0; i < rfid.uid.size; i++) {
    if (rfid.uid.uidByte[i] < 0x10) tagUid += "0";
    tagUid += String(rfid.uid.uidByte[i], HEX);
    if (i < rfid.uid.size - 1) tagUid += ":";
  }
  tagUid.toUpperCase();

  Serial.print("\n[RFID DETECTED] Tag UID: ");
  Serial.println(tagUid);

  // Build JSON message for AWS IoT Core
  StaticJsonDocument<256> doc;
  doc["device_id"] = DEVICE_ID;
  doc["tag_uid"]   = tagUid;
  doc["subnet"]    = "192.168.10.0/24";
  doc["timestamp"] = millis();

  char jsonBuffer[256];
  serializeJson(doc, jsonBuffer);

  // Publish to AWS IoT Core MQTT topic
  if (mqttClient.publish(TOPIC_PUBLISH, jsonBuffer)) {
    Serial.print("Published to topic '");
    Serial.print(TOPIC_PUBLISH);
    Serial.println("': ");
    Serial.println(jsonBuffer);
  } else {
    Serial.println("Failed to publish MQTT message to AWS IoT Core!");
  }

  // Halt RFID Card
  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();
}
