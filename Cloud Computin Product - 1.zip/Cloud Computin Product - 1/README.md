# Virtual Classroom Access Gate

> **An IoT-enabled smart gate that simulates student entry to a classroom subnet; validates credentials in real time; logs audit trails to Amazon DynamoDB; and activates hardware status LEDs (Green = Allowed, Red = Denied).**

---

## 👥 Project Team & Speaker Topic Division

| S.No | Student Name | Roll Number | Assigned Presentation Topic | Core Responsibilities |
| :---: | :--- | :---: | :--- | :--- |
| **1** | **D. Taejaswini** | `2503A52752` | **Introduction & Problem Statement** | Motivation, traditional attendance vs smart gates, subnet access concept. |
| **2** | **B. Mounika** | `2503A52756` | **Hardware Architecture & Circuit Design** | ESP32 microcontroller, MFRC522 RFID reader (SPI), Red/Green LED actuation, wiring. |
| **3** | **V. Pragathi Vijaya Lakshmi** | `2503A52761` | **AWS Cloud Infrastructure & MQTT Broker** | AWS IoT Core topics, X.509 certs, DynamoDB tables (Whitelist & AccessLogs). |
| **4** | **A. Spurthi** | `2503A52764` | **Software Implementation & Code Walkthrough** | ESP32 Arduino C++ firmware, AWS Lambda Python handler, JSON payloads. |
| **5** | **Praneetha Kanchi** | `2503A52772` | **Lecturer Dashboard, Live Demo & Results** | HTML/CSS/JS web portal, live RFID simulator, benchmarks, and future scope. |

---

## 📁 Project Directory Structure

```text
d:\Cloud Computing\
├── index.html                               # Modern Lecturer Dashboard (HTML structure)
├── style.css                                # Cyber Slate & Glassmorphism Dashboard styling (CSS)
├── script.js                                # Real-time dashboard controller, audio & charts (JavaScript)
├── app.py                                   # Python Flask backend server & REST API
├── lambda_function.py                       # AWS Lambda event handler (IoT Core -> DynamoDB -> ESP32)
├── esp32_firmware.ino                       # ESP32 C++ firmware for MFRC522 RFID & LEDs
├── iot_simulator.py                         # Interactive terminal RFID tap simulator
├── generate_ppt.py                          # Script to regenerate presentation deck
├── Virtual_Classroom_Access_Gate_Presentation.pptx # Ready-to-present PowerPoint presentation (12 slides)
└── README.md                                # Project documentation & presentation guide
```

---

## 🚀 How to Run the Lecturer Dashboard

### Option 1: Standalone Instant Mode (No Setup Required)
Simply double-click or open `index.html` in Google Chrome, Microsoft Edge, or any modern web browser.
- Full interactive RFID simulation is built-in.
- Features audio feedback chimes via the Web Audio API.
- Dynamic Chart.js visualizations and CSV log exports work instantly.

### Option 2: Full Python Backend & REST API Mode
1. Open PowerShell or Terminal in `d:\Cloud Computing`:
   ```bash
   python app.py
   ```
2. Navigate to:
   ```text
   http://localhost:5000
   ```
3. Test terminal taps in a second window:
   ```bash
   python iot_simulator.py
   ```

---

## 🔌 Hardware Circuit Connections (ESP32)

### MFRC522 RFID Reader Pinout (SPI Bus)
| MFRC522 Pin | ESP32 Pin | Function |
| :--- | :--- | :--- |
| **SDA (SS)** | `GPIO 5` | SPI Chip Select |
| **SCK** | `GPIO 18` | SPI Clock |
| **MOSI** | `GPIO 23` | SPI Master Out Slave In |
| **MISO** | `GPIO 19` | SPI Master In Slave Out |
| **RST** | `GPIO 22` | Module Reset |
| **3.3V** | `3V3` | Power Supply (**Do NOT connect to 5V**) |
| **GND** | `GND` | Ground |

### Status Indicators (LEDs)
| Component | ESP32 Pin | Logic Level | Gate State |
| :--- | :--- | :--- | :--- |
| **Green LED Anode** | `GPIO 2` | `HIGH` (2.5s) | **ALLOWED**: Turnstile unlocked, Subnet bound |
| **Red LED Anode** | `GPIO 4` | `HIGH` (2.0s) | **DENIED**: Intruder/Expired, Gate locked |
| **LED Cathodes** | `GND` | Series 220Ω Resistor | Ground return |

---

## ☁️ AWS Cloud Architecture Pipeline

```text
 [Student RFID Badge]
         │ (13.56 MHz Radio Frequency)
         ▼
 [MFRC522 Reader + ESP32]
         │ (MQTT over TLS 1.2 / Port 8883)
         │ Topic: 'classroom/gate/request'
         ▼
  [AWS IoT Core]
         │ (IoT Rules Engine SQL)
         ▼
  [AWS Lambda (Python 3.12)]
      ├── 1. Query: DynamoDB 'StudentRoster' (Whitelist)
      ├── 2. Decision: ALLOWED (Active) vs DENIED (Unregistered/Expired)
      ├── 3. Persist: DynamoDB 'VirtualClassroom_AccessLogs' (Audit Trail)
      └── 4. Publish MQTT: Topic 'classroom/gate/response'
         │
         ▼
 [ESP32 Firmware Callback]
      ├── If ALLOWED: Green LED ON (GPIO 2) -> Unlocks Gate
      └── If DENIED:  Red LED ON (GPIO 4)   -> Keeps Gate Locked
         │
         ▼
 [Lecturer Dashboard (HTML/CSS/JS + Flask)]
      └── Real-time visual monitoring, metrics, IP allocation & CSV export
```

---

## 📊 PowerPoint Slide Overview (`Virtual_Classroom_Access_Gate_Presentation.pptx`)

1. **Slide 1**: Title Slide highlighting Project Name and all 5 Group Members with Roll Numbers.
2. **Slide 2**: Presentation Agenda & Speaker Topic Division.
3. **Slide 3**: **Part 1 (D. Taejaswini)** - Background & Problem Statement in Classroom Access.
4. **Slide 4**: **Part 2 (B. Mounika)** - Hardware Architecture (ESP32, MFRC522, LEDs).
5. **Slide 5**: **Part 2 (B. Mounika)** - Complete Circuit Wiring & Pin Mapping Table.
6. **Slide 6**: **Part 3 (V. Pragathi V.L.)** - AWS Cloud Architecture & IoT Core Message Routing.
7. **Slide 7**: **Part 3 (V. Pragathi V.L.)** - DynamoDB Schema (StudentRoster & AccessLogs).
8. **Slide 8**: **Part 4 (A. Spurthi)** - ESP32 Firmware C++ Code Walkthrough & Debounce Logic.
9. **Slide 9**: **Part 4 (A. Spurthi)** - AWS Lambda Python Handler & Verification Engine.
10. **Slide 10**: **Part 5 (Praneetha Kanchi)** - Interactive Lecturer Dashboard Features & UI.
11. **Slide 11**: **Part 5 (Praneetha Kanchi)** - Test Case Results & Performance Benchmarks.
12. **Slide 12**: **Summary & Future Scope (All Members)** - Multi-factor auth, SDN, and LMS sync.
