"""
Virtual Classroom Access Gate - AWS DynamoDB Setup & Seeding Utility
Automatically creates and seeds:
1. 'VirtualClassroom_StudentRoster' (Whitelist of authorized student RFID tags)
2. 'VirtualClassroom_AccessLogs' (Audit log table for ESP32 entry events)
"""

import boto3
import os
import sys
import time

REGION = os.environ.get('AWS_DEFAULT_REGION', 'us-east-1')

def setup_aws_dynamodb():
    print("=" * 65)
    print(f" AWS DYNAMODB AUTO-SETUP & SEEDING UTILITY (Region: {REGION})")
    print("=" * 65)

    try:
        dynamodb = boto3.resource('dynamodb', region_name=REGION)
        client = boto3.client('dynamodb', region_name=REGION)
    except Exception as e:
        print(f"❌ Failed to connect to AWS: {e}")
        print("   Make sure you ran 'aws configure' or set AWS_ACCESS_KEY_ID.")
        return

    existing_tables = client.list_tables().get('TableNames', [])
    print(f"Existing DynamoDB Tables: {existing_tables}\n")

    # 1. Create Student Roster Table
    roster_table_name = 'VirtualClassroom_StudentRoster'
    if roster_table_name not in existing_tables:
        print(f"Creating Table '{roster_table_name}'...")
        table = dynamodb.create_table(
            TableName=roster_table_name,
            KeySchema=[
                {'AttributeName': 'tag_uid', 'KeyType': 'HASH'}  # Partition key
            ],
            AttributeDefinitions=[
                {'AttributeName': 'tag_uid', 'AttributeType': 'S'}
            ],
            BillingMode='PAY_PER_REQUEST'
        )
        print("Waiting for table to be ACTIVE...")
        table.wait_until_exists()
        print(f"✅ Created '{roster_table_name}' successfully!")
    else:
        print(f"✔ Table '{roster_table_name}' already exists.")

    # 2. Create Access Logs Table
    logs_table_name = 'VirtualClassroom_AccessLogs'
    if logs_table_name not in existing_tables:
        print(f"\nCreating Table '{logs_table_name}'...")
        table = dynamodb.create_table(
            TableName=logs_table_name,
            KeySchema=[
                {'AttributeName': 'log_id', 'KeyType': 'HASH'}  # Partition key
            ],
            AttributeDefinitions=[
                {'AttributeName': 'log_id', 'AttributeType': 'S'}
            ],
            BillingMode='PAY_PER_REQUEST'
        )
        print("Waiting for table to be ACTIVE...")
        table.wait_until_exists()
        print(f"✅ Created '{logs_table_name}' successfully!")
    else:
        print(f"✔ Table '{logs_table_name}' already exists.")

    # 3. Seed Authorized Student Roster
    print(f"\nSeeding student records into '{roster_table_name}'...")
    roster_table = dynamodb.Table(roster_table_name)

    students = [
        {
            "tag_uid": "A3:4F:91:2B",
            "name": "D. Taejaswini",
            "roll_no": "2503A52752",
            "ip": "192.168.10.15",
            "subnet": "192.168.10.0/24",
            "batch": "Cloud Computing - Sec A",
            "status": "ACTIVE"
        },
        {
            "tag_uid": "B8:21:7C:90",
            "name": "B. Mounika",
            "roll_no": "2503A52756",
            "ip": "192.168.10.16",
            "subnet": "192.168.10.0/24",
            "batch": "Cloud Computing - Sec A",
            "status": "ACTIVE"
        },
        {
            "tag_uid": "C1:89:33:DE",
            "name": "V. Pragathi Vijaya Lakshmi",
            "roll_no": "2503A52761",
            "ip": "192.168.10.17",
            "subnet": "192.168.10.0/24",
            "batch": "Cloud Computing - Sec A",
            "status": "ACTIVE"
        },
        {
            "tag_uid": "D4:55:1A:F2",
            "name": "A. Spurthi",
            "roll_no": "2503A52764",
            "ip": "192.168.10.18",
            "subnet": "192.168.10.0/24",
            "batch": "Cloud Computing - Sec A",
            "status": "ACTIVE"
        },
        {
            "tag_uid": "E9:60:44:0B",
            "name": "Praneetha Kanchi",
            "roll_no": "2503A52772",
            "ip": "192.168.10.19",
            "subnet": "192.168.10.0/24",
            "batch": "Cloud Computing - Sec A",
            "status": "ACTIVE"
        }
    ]

    for s in students:
        roster_table.put_item(Item=s)
        print(f"  ✔ Inserted: {s['name']} ({s['roll_no']}) -> UID: {s['tag_uid']}")

    print("\n" + "=" * 65)
    print("🎉 ALL AWS DYNAMODB TABLES READY AND SEEDED!")
    print("=" * 65)

if __name__ == '__main__':
    setup_aws_dynamodb()
