"""
Virtual Classroom Access Gate - Python Web Backend & API Server
Framework: Flask
Features:
- Serves the Interactive Lecturer Dashboard (HTML/CSS/JS)
- Real-time REST API for Gate Telemetry & Card Scans
- Hybrid DynamoDB Integration:
  Connects to AWS DynamoDB via Boto3 when AWS credentials exist,
  with seamless automatic in-memory fallback for local college lab demos.
"""

import os
import json
import time
from datetime import datetime
from flask import Flask, jsonify, request, send_from_directory

app = Flask(__name__, static_folder=".")

# Enable CORS for requests coming from the S3 static website endpoint
@app.after_request
def add_cors_headers(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type,Authorization'
    response.headers['Access-Control-Allow-Methods'] = 'GET,PUT,POST,DELETE,OPTIONS'
    return response

# Optional AWS Boto3 Setup
AWS_ENABLED = False
dynamodb = None
try:
    import boto3
    # Check if credentials or region are available
    if os.environ.get("AWS_DEFAULT_REGION") or os.path.exists(os.path.expanduser("~/.aws/credentials")):
        dynamodb = boto3.resource('dynamodb', region_name=os.environ.get('AWS_DEFAULT_REGION', 'us-east-1'))
        AWS_ENABLED = True
        print("[INFO] Connected to AWS DynamoDB.")
except Exception as e:
    print(f"[INFO] Running in local demo mode (Boto3 fallback active: {e})")

STUDENT_ROSTER_DB = {
    "A3:4F:91:2B": {
        "name": "D. Taejaswini",
        "roll_no": "2503A52752",
        "tag_uid": "A3:4F:91:2B",
        "ip": "192.168.10.15",
        "status": "ACTIVE",
        "batch": "Cloud Computing - Sec A",
        "permission": "Virtual Lab & Gateway"
    },
    "B8:21:7C:90": {
        "name": "B. Mounika",
        "roll_no": "2503A52756",
        "tag_uid": "B8:21:7C:90",
        "ip": "192.168.10.16",
        "status": "ACTIVE",
        "batch": "Cloud Computing - Sec A",
        "permission": "Virtual Lab & Gateway"
    },
    "C1:89:33:DE": {
        "name": "V. Pragathi Vijaya Lakshmi",
        "roll_no": "2503A52761",
        "tag_uid": "C1:89:33:DE",
        "ip": "192.168.10.17",
        "status": "ACTIVE",
        "batch": "Cloud Computing - Sec A",
        "permission": "Virtual Lab & Gateway"
    },
    "D4:55:1A:F2": {
        "name": "A. Spurthi",
        "roll_no": "2503A52764",
        "tag_uid": "D4:55:1A:F2",
        "ip": "192.168.10.18",
        "status": "ACTIVE",
        "batch": "Cloud Computing - Sec A",
        "permission": "Virtual Lab & Gateway"
    },
    "E9:60:44:0B": {
        "name": "Praneetha Kanchi",
        "roll_no": "2503A52772",
        "tag_uid": "E9:60:44:0B",
        "ip": "192.168.10.19",
        "status": "ACTIVE",
        "batch": "Cloud Computing - Sec A",
        "permission": "Virtual Lab & Gateway"
    }
}

# In-memory logs store (seeded with initial presentation events)
in_memory_logs = [
    {
        "timestamp": "10:14:02",
        "name": "Praneetha Kanchi",
        "rollNo": "2503A52772",
        "tagUid": "E9:60:44:0B",
        "assignedIp": "192.168.10.19",
        "decision": "ALLOWED",
        "reason": "Subnet Authorization Verified (Cloud Sec-A)"
    },
    {
        "timestamp": "10:11:45",
        "name": "A. Spurthi",
        "rollNo": "2503A52764",
        "tagUid": "D4:55:1A:F2",
        "assignedIp": "192.168.10.18",
        "decision": "ALLOWED",
        "reason": "Subnet Authorization Verified (Cloud Sec-A)"
    },
    {
        "timestamp": "10:08:30",
        "name": "Guest Student",
        "rollNo": "2503A59999",
        "tagUid": "F0:11:82:77",
        "assignedIp": "None",
        "decision": "DENIED",
        "reason": "Access Expired: Not enrolled in current Lab Subnet"
    },
    {
        "timestamp": "10:05:12",
        "name": "V. Pragathi Vijaya Lakshmi",
        "rollNo": "2503A52761",
        "tagUid": "C1:89:33:DE",
        "assignedIp": "192.168.10.17",
        "decision": "ALLOWED",
        "reason": "Subnet Authorization Verified (Cloud Sec-A)"
    },
    {
        "timestamp": "10:02:18",
        "name": "B. Mounika",
        "rollNo": "2503A52756",
        "tagUid": "B8:21:7C:90",
        "assignedIp": "192.168.10.16",
        "decision": "ALLOWED",
        "reason": "Subnet Authorization Verified (Cloud Sec-A)"
    },
    {
        "timestamp": "09:58:40",
        "name": "D. Taejaswini",
        "rollNo": "2503A52752",
        "tagUid": "A3:4F:91:2B",
        "assignedIp": "192.168.10.15",
        "decision": "ALLOWED",
        "reason": "Subnet Authorization Verified (Cloud Sec-A)"
    }
]


# Static Web File Serving
@app.route('/')
def serve_index():
    return send_from_directory('.', 'index.html')


@app.route('/style.css')
def serve_css():
    return send_from_directory('.', 'style.css')


@app.route('/script.js')
def serve_js():
    return send_from_directory('.', 'script.js')


# REST API Endpoints
@app.route('/api/status', methods=['GET'])
def get_status():
    return jsonify({
        "status": "ONLINE",
        "service": "Virtual Classroom Access Gate Backend",
        "target_subnet": "192.168.10.0/24",
        "aws_connected": AWS_ENABLED,
        "active_students": len(STUDENT_ROSTER_DB),
        "total_logs": len(in_memory_logs)
    })


@app.route('/api/roster', methods=['GET'])
def get_roster():
    if AWS_ENABLED and dynamodb:
        try:
            table = dynamodb.Table('VirtualClassroom_StudentRoster')
            res = table.scan(Limit=100)
            items = res.get('Items', [])
            if items:
                return jsonify(items)
        except Exception as e:
            print(f"[WARN] Failed to fetch roster from DynamoDB: {e}")
    return jsonify(list(STUDENT_ROSTER_DB.values()))


@app.route('/api/logs', methods=['GET'])
def get_logs():
    if AWS_ENABLED and dynamodb:
        try:
            table = dynamodb.Table('VirtualClassroom_AccessLogs')
            res = table.scan(Limit=100)
            items = res.get('Items', [])
            if items:
                formatted = []
                for it in items:
                    formatted.append({
                        "timestamp": it.get('timestamp', ''),
                        "name": it.get('student_name') or it.get('name', 'Unknown'),
                        "rollNo": it.get('roll_no', 'N/A'),
                        "tagUid": it.get('tag_uid', ''),
                        "assignedIp": it.get('assigned_ip') or it.get('ip', 'None'),
                        "decision": it.get('decision', 'DENIED'),
                        "ledHardware": f"{it.get('led_activated', 'RED')} LED ACTIVE",
                        "reason": it.get('reason', '')
                    })
                # Sort latest first if timestamp exists
                formatted.sort(key=lambda x: str(x.get('timestamp', '')), reverse=True)
                return jsonify(formatted)
        except Exception as e:
            print(f"[WARN] Error scanning DynamoDB AccessLogs: {e}")
    return jsonify(in_memory_logs)


@app.route('/api/scan', methods=['POST'])
def process_scan():
    """
    Simulates or receives an RFID card scan event.
    Payload: {"tag_uid": "A3:4F:91:2B", ...} or frontend log object
    """
    data = request.get_json() or {}

    tag_uid = data.get('tagUid') or data.get('tag_uid', '')
    tag_uid = tag_uid.strip().upper()

    now_str = datetime.now().strftime("%H:%M:%S")

    if tag_uid in STUDENT_ROSTER_DB:
        student = STUDENT_ROSTER_DB[tag_uid]
        decision = "ALLOWED"
        led = "GREEN"
        name = student["name"]
        roll_no = student["roll_no"]
        ip = student["ip"]
        reason = "Subnet Authorization Verified (Cloud Sec-A)"
    else:
        decision = "DENIED"
        led = "RED"
        name = data.get("name", "Unknown Visitor")
        roll_no = data.get("rollNo", "UNKNOWN")
        ip = "None"
        reason = "Tag UID not enrolled in DynamoDB StudentRoster"

    log_entry = {
        "timestamp": now_str,
        "name": name,
        "rollNo": roll_no,
        "tagUid": tag_uid,
        "assignedIp": ip,
        "decision": decision,
        "ledHardware": f"{led} LED ACTIVE",
        "reason": reason
    }

    in_memory_logs.insert(0, log_entry)

    # If AWS DynamoDB is enabled, write item into table
    if AWS_ENABLED and dynamodb:
        try:
            table = dynamodb.Table('VirtualClassroom_AccessLogs')
            table.put_item(Item={
                'log_id': f"LOG-{int(time.time()*1000)}",
                'timestamp': now_str,
                'tag_uid': tag_uid,
                'name': name,
                'roll_no': roll_no,
                'decision': decision,
                'ip': ip,
                'reason': reason
            })
        except Exception as e:
            print(f"[WARN] DynamoDB write failed: {e}")

    return jsonify(log_entry), 200


@app.route('/api/clear', methods=['POST'])
def clear_logs():
    global in_memory_logs
    in_memory_logs = []
    return jsonify({"message": "Logs cleared successfully"}), 200


if __name__ == '__main__':
    print("=" * 65)
    print("  VIRTUAL CLASSROOM ACCESS GATE - LECTURER DASHBOARD SERVER")
    print("=" * 65)
    print("  * Dashboard URL: http://localhost:5000")
    print("  * API Endpoint:  http://localhost:5000/api/logs")
    print("  * Target Subnet: 192.168.10.0/24")
    print("  * Press Ctrl+C to stop the server")
    print("=" * 65)
    app.run(host='0.0.0.0', port=5000, debug=True)
